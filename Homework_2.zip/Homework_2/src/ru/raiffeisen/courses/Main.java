package ru.raiffeisen.courses;

import ru.raiffeisen.courses.Bankomat.Bankomat;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Bankomat bankomat = new Bankomat();
        boolean clientVariant = true;
        while (clientVariant) {

            switch (bankomat.clientChoice()) {
                case 1:
                    bankomat.getMoneyFromClient();
                    break;
                case 2:
                    bankomat.getMoneyFromBankomat();
                    break;
                default:
                    System.out.println("Wrong answer ! ");
            }
            System.out.println("Do you want to continue (Y/N)?");
            Scanner scanner = new Scanner(System.in);
            String clientMessage = scanner.next();
            if (clientMessage.toUpperCase().equals("Y")) {
                clientVariant = true;
            } else {
                System.out.println("Finish! Goodbye! Thank you! ");
                clientVariant = false;
            }

        }
    }
}
