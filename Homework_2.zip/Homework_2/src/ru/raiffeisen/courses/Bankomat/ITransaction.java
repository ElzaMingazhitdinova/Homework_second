package ru.raiffeisen.courses.Bankomat;

public interface ITransaction {

    float getMoneyFromClient();
    float getMoneyFromBankomat ();

}
