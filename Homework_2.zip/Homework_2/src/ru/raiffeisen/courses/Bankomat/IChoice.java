package ru.raiffeisen.courses.Bankomat;

public interface IChoice {

    int clientChoice();

}
