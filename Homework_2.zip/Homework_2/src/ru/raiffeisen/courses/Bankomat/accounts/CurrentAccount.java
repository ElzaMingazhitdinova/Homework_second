package ru.raiffeisen.courses.Bankomat.accounts;

import ru.raiffeisen.courses.Bankomat.accounts.Account;

public class CurrentAccount extends Account {

    private int accountNumber;
    public float clientBalance = 0;

    public int getAccountNumber() {
        return accountNumber;
    }

    public float getClientBalance() {
        return clientBalance;
    }

    public void setClientBalance(float clientBalance) {
        this.clientBalance = clientBalance;
    }

    public CurrentAccount(int accountNumber, float clientBalance1) {

        this.accountNumber = accountNumber;
        this.clientBalance = clientBalance1;
    }

    public void setAccountNumber(int accountNumber) {
        this.accountNumber = accountNumber;
    }

    @Override
    public int clientChoice() {
        return 0;
    }

    @Override
    public float getMoneyFromClient() {
        return 0;
    }

    @Override
    public float getMoneyFromBankomat() {
        return 0;
    }
}
