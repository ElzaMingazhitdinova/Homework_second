package ru.raiffeisen.courses.Bankomat.accounts;

public class CreditAccount extends Account {

    public CreditAccount(float clientBalance) {

    }

    @Override
    public int clientChoice() {
        return 0;
    }

    @Override
    public float getMoneyFromClient() {
        return 0;
    }

    @Override
    public float getMoneyFromBankomat() {
        return 0;
    }
}
