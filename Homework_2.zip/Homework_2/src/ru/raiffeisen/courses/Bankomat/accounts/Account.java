package ru.raiffeisen.courses.Bankomat.accounts;

import ru.raiffeisen.courses.Bankomat.IChoice;
import ru.raiffeisen.courses.Bankomat.ITransaction;

import java.util.Scanner;

public abstract class Account implements ITransaction, IChoice {

}
