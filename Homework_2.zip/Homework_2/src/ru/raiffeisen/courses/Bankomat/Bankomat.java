package ru.raiffeisen.courses.Bankomat;

import ru.raiffeisen.courses.Bankomat.accounts.Account;
import ru.raiffeisen.courses.Bankomat.accounts.CurrentAccount;

import java.util.Scanner;

public class Bankomat {


    CurrentAccount currentAccount = new CurrentAccount(435555555, 0);


    public Bankomat() {
          }


    public float getClientBalance() {
        return currentAccount.clientBalance;
    }

    public int clientChoice() {
        System.out.println("Hello! Do you want to add or take your money from Bankomat(1/2)?");
        Scanner scanner = new Scanner(System.in);
        int clientMessage = scanner.nextInt();


        return clientMessage;
    }

    public float getMoneyFromClient() {


        System.out.println("Fine!Please enter the sum which you want add to your account");
        Scanner scanner1 = new Scanner(System.in);
        float moneyToAccount = scanner1.nextFloat();

        currentAccount.clientBalance += moneyToAccount;
        System.out.println("Your balance = " + currentAccount.clientBalance);

        return currentAccount.clientBalance;
    }


    public float getMoneyFromBankomat() {

        System.out.println("Fine!Please enter the sum which you want get from your account");
        Scanner scanner1 = new Scanner(System.in);
        float moneyToAccount = scanner1.nextFloat();

        currentAccount.clientBalance -= moneyToAccount;
        System.out.println("Your balance = " + currentAccount.clientBalance);

        return currentAccount.clientBalance;
    }

}
