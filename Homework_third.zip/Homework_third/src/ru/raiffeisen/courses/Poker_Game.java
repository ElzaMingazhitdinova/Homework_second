package ru.raiffeisen.courses;

import java.util.Scanner;

public class Poker_Game {

    private String mast[] = {"Пики", "Бубны", "Трефы", "Червы"};

    private String weigthOfCart[] =
            {"Двойка", "Тройка", "Четверка", "Пятерка", "Шестерка", "Семерка", "Восьмерка", "Девятка", "Валет", "Дама",
             "Король", "Туз"};

    private int countOfCardsForEachPlayer = 5;

    private int countOfPlayers;


    private int allCountOfCards = mast.length * weigthOfCart.length;

    public Poker_Game() {
        this.mast = mast;
        this.weigthOfCart = weigthOfCart;
        this.countOfCardsForEachPlayer = countOfCardsForEachPlayer;
        this.countOfPlayers = countOfPlayers;
        this.allCountOfCards = allCountOfCards;
        this.masOfAllCarts = masOfAllCarts;

    }

    public String[] getMast() {
        return mast;
    }

    public String[] getWeigthOfCart() {
        return weigthOfCart;
    }

    public int getCountOfCardsForEachPlayer() {
        return countOfCardsForEachPlayer;
    }

    public int getCountOfPlayers() {
        return countOfPlayers;
    }

    public int getAllCountOfCards() {
        return allCountOfCards;
    }

    public String[] getMasOfAllCarts() {
        return masOfAllCarts;
    }

    public void setMast(String[] mast) {
        this.mast = mast;
    }

    public void setWeigthOfCart(String[] weigthOfCart) {
        this.weigthOfCart = weigthOfCart;
    }

    public void setCountOfCardsForEachPlayer(int countOfCardsForEachPlayer) {
        this.countOfCardsForEachPlayer = countOfCardsForEachPlayer;
    }

    public void setCountOfPlayers(int countOfPlayers) {
        this.countOfPlayers = countOfPlayers;
    }

    public void setAllCountOfCards(int allCountOfCards) {
        this.allCountOfCards = allCountOfCards;
    }

    public void setMasOfAllCarts(String[] masOfAllCarts) {
        this.masOfAllCarts = masOfAllCarts;
    }


    String[] masOfAllCarts = new String[allCountOfCards];


    public int vvod() {
        System.out.println("Please, input how many players want to play");
        Scanner userScanner = new Scanner(System.in);
        int countOfPlayers = userScanner.nextInt();

        return countOfPlayers;
    }

    public String[] newPackOfCards() {
        // String[] masOfAllCarts = new String[48];
        for (int i = 0; i < mast.length; i++) {
            for (int j = 0; j < weigthOfCart.length; j++) {
                masOfAllCarts[i * weigthOfCart.length + j] = mast[i] + " " + weigthOfCart[j];
                //System.out.println(masOfAllCarts[i * mast.length + j]);
            }
        }


        return masOfAllCarts;
    }


    public String[] changePlaceOfEachCard() {
        for (int i = 0; i < allCountOfCards; i++) {
            int toChangeTheCards = i + (int) (Math.random() * (allCountOfCards - i));
            String temp = masOfAllCarts[toChangeTheCards];
            masOfAllCarts[toChangeTheCards] = masOfAllCarts[i];
            masOfAllCarts[i] = temp;

        }

    return masOfAllCarts;}

    public void razdacha(int countOfPlayers) {
        for (int i = 0; i < countOfPlayers * countOfCardsForEachPlayer; i++)

        {
            if (countOfPlayers > 9 || countOfPlayers <= 0) {
                System.out.println("Attention! Mistake! Try again");
                break;
            }
            //for (int j = 0; j < countOfCardsForEachPlayer; j++) {


            System.out.println(masOfAllCarts[i]);
            if ((i + 1) % 5 == 0) {
                System.out.println("                       ");
            }

        }

    }
}


