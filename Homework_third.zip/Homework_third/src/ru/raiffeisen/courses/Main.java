package ru.raiffeisen.courses;

import java.util.Random;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        int countOfPlayers;

        Poker_Game poker_game = new Poker_Game();

        countOfPlayers= poker_game.vvod();

        poker_game.newPackOfCards();
        poker_game. changePlaceOfEachCard();

        poker_game.razdacha(countOfPlayers);

    }
}



