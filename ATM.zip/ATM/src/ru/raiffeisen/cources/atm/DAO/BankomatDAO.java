package ru.raiffeisen.cources.atm.DAO;

import ru.raiffeisen.cources.atm.connection.IConnectionManager;
import ru.raiffeisen.cources.atm.connection.SingleConnectionManager;
import ru.raiffeisen.cources.atm.model.account.Account;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class BankomatDAO extends AbstractDao {

    public BankomatDAO(IConnectionManager iConnectionManager) {
        super(iConnectionManager);
    }


    PreparedStatement statement = null;

    {
        try {
            statement = super.iConnectionManager.getConnection().prepareStatement(
                    "insert into \"Principal\" values (?,?,?,?);" + "insert into \"Account\"  values(?,?,?,?);\n"
                            + "insert into \"Money\" values(?,?,?);\n" + "insert into \"CurrentScore\" values(?,?,?,?,?);\n"
                            + "insert into \"DebetScore\" values(?,?,?,?,?);\n"
                            + "insert into \"CreditScore\" values(?,?,?,?,?);"

            );
        } catch (SQLException e) {
            e.printStackTrace();
        }
        statement.setObject(1, Account);

    }

}

