package ru.raiffeisen.cources.atm.DAO;

import ru.raiffeisen.cources.atm.connection.IConnectionManager;
import ru.raiffeisen.cources.atm.connection.SingleConnectionManager;

public abstract class AbstractDao {

    public static boolean IS_DRIVER_ACCESSIBLE;

    static {

        try {
            Class.forName("org.postgresql.Driver");
            IS_DRIVER_ACCESSIBLE = true;
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
            IS_DRIVER_ACCESSIBLE = false;
        }
    }

    public static boolean isIsDriverAccessible() {
        return IS_DRIVER_ACCESSIBLE;
    }


    protected IConnectionManager iConnectionManager;

    public AbstractDao(IConnectionManager iConnectionManager) {
        this.iConnectionManager = iConnectionManager;
    }
}
