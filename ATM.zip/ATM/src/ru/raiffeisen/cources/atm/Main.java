package ru.raiffeisen.cources.atm;

import ru.raiffeisen.cources.atm.DAO.BankomatDAO;
import ru.raiffeisen.cources.atm.connection.SingleConnectionManager;
import ru.raiffeisen.cources.atm.model.account.Account;
import ru.raiffeisen.cources.atm.model.account.Principal;
import ru.raiffeisen.cources.atm.model.money.Money;
import ru.raiffeisen.cources.atm.model.score.CreditScore;
import ru.raiffeisen.cources.atm.model.score.CurrentScore;
import ru.raiffeisen.cources.atm.model.score.DebetScore;
import ru.raiffeisen.cources.atm.model.score.Score;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        ATM atm = new ATM();
        Scanner scanner = new Scanner(System.in);
        int val = scanner.nextInt();

        Money money = new Money(val, "RUR");
        atm.getCreditScore().addMoney(money);

        Principal principal = new Principal("Kalinin", "Vladislav", "Petrovich", 25);

        Account account = new Account(principal, "superpuper123", "Qwerty2525");

        CreditScore creditScore = new CreditScore(money,account,2);

        DebetScore debetScore = new DebetScore(money, account, 2,creditScore);

        CurrentScore currentScore = new CurrentScore(money,account, 1,debetScore);

        BankomatDAO bankomatDAO = new BankomatDAO(new SingleConnectionManager());

    }
}
