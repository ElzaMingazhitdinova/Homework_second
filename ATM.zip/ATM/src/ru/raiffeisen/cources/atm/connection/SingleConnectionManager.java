package ru.raiffeisen.cources.atm.connection;

import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.SQLException;


public class SingleConnectionManager implements IConnectionManager {

    public static final String URL = "jdbc:postgresql://localhost:5432/Банкомат";
    public static final String Password = "Qwerty251096";
    public static final String USERNAME = "postgres";

    private Connection connection;

    public SingleConnectionManager() {
        Connection connection = null;


        try {
            connection = DriverManager.getConnection(URL, USERNAME, Password);
        } catch (SQLException e) {
            e.printStackTrace();
        }

    }

    @Override
    public Connection getConnection() {
       return  this.connection;
    }
}


