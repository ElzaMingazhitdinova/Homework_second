package ru.raiffeisen.courses.weapons;

public class Gun extends Weapon {

    public Gun(int power) {
        super(power);
    }

    @Override
    public void shoot() {
        System.out.println("Bang bang");
    }

}
