package ru.raiffeisen.courses.weapons;

public class BFG extends Weapon {

    public BFG(int power) {
        super(power);
    }

    @Override
    public void shoot() {
        System.out.println("Big booom");
    }
}
