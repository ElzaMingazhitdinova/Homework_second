package ru.raiffeisen.courses.weapons;

public class ShortGun extends  Weapon {

    public ShortGun(int power) {
        super(power);
    }

    @Override
    public void shoot() {
        System.out.println("little boom");

        }
}
