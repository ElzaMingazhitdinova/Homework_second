package ru.raiffeisen.courses;

import ru.raiffeisen.courses.employes.ISalaryTaker;
import ru.raiffeisen.courses.weapons.BFG;
import ru.raiffeisen.courses.weapons.Gun;
import ru.raiffeisen.courses.weapons.ShortGun;
import ru.raiffeisen.courses.weapons.Weapon;

public class Main {

    public static void main(String[] args) {

        Weapon[] weapons = new Weapon[5];

        weapons[0] = new Gun(5);
        weapons[1] = new ShortGun(10);
        weapons[2] = new BFG(1000);
        weapons[3] = new ShortGun(7);
        weapons[4] = new Gun(9);


        for (Weapon weapon: weapons) {

            weapon.shoot();

        }
    }
}
