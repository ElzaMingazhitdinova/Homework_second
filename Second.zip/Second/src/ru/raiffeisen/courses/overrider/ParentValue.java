package ru.raiffeisen.courses.overrider;

public class ParentValue {}
