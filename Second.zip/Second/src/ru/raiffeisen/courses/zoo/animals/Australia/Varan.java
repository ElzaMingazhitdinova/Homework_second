package ru.raiffeisen.courses.zoo.animals.Australia;

import ru.raiffeisen.courses.zoo.animals.Reptiles;

public class Varan extends Reptiles {

    private boolean poisonous;


    public boolean isPoisonous() {
        return poisonous;
    }

    public void setPoisonous(boolean poisonous) {
        this.poisonous = poisonous;
    }

    public Varan(String name, String colorDescription, int tailSize, boolean poisonous) {
        super(name, colorDescription, tailSize);
        this.poisonous = poisonous;
    }


    @Override
    public String toString() {
        return "Varan{" + "poisonous =" + poisonous + ", name = '" + name + '\'' + ", colorDescription = '"
                + colorDescription + '\'' + '}';
    }
}
