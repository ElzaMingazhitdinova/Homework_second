package ru.raiffeisen.courses.zoo.animals.Europe;

import ru.raiffeisen.courses.zoo.animals.Birds;

public class Eagle extends Birds {

    private int eyeStregth;

    public int getEyeStregth() {
        return eyeStregth;
    }

    public void setEyeStregth(int eyeStregth) {
        this.eyeStregth = eyeStregth;
    }

    public Eagle(String name, String colorDescription, short wingSize, int eyeStregth) {
        super(name, colorDescription, wingSize);
        this.eyeStregth = eyeStregth;
    }


    @Override
    public String toString() {
        return "Eagle{" + "eyeStregth=" + eyeStregth + ", name='" + name + '\'' + ", colorDescription='"
                + colorDescription + '\'' + '}';
    }
}
