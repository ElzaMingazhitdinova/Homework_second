package ru.raiffeisen.courses.zoo.animals;

public abstract class Reptiles extends Animal {

    private int  tailSize;

    public int getTailSize() {
        return tailSize;
    }

    public Reptiles(String name, String colorDescription, int tailSize) {
        super(name, colorDescription);
        this.tailSize = tailSize;
    }


    @Override
    public String toString() {
        return "Reptiles{" + "tailSize=" + tailSize + ", name='" + name + '\'' + ", colorDescription='"
                + colorDescription + '\'' + '}';
    }
}
