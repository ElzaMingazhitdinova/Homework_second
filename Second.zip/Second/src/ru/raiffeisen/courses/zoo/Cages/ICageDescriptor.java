package ru.raiffeisen.courses.zoo.Cages;

public interface ICageDescriptor {

    String getCageDescription();
}
