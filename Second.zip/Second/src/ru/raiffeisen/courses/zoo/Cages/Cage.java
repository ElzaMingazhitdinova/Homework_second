package ru.raiffeisen.courses.zoo.Cages;

import ru.raiffeisen.courses.zoo.animals.Animal;

public abstract class Cage implements ICageDescriptor  {

    protected Animal[] animals;

    public Cage(Animal[] animals) {
        this.animals = animals;
    }

    public String getCageDescription() {

        StringBuilder descriptionBuilder = new StringBuilder();

        for (Animal animal : animals) {
            descriptionBuilder.append(animal.toString());

        }
    return descriptionBuilder.toString(); }



    public String getCageNumber
}
