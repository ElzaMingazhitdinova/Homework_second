package ru.raiffeisen.courses.zoo;

import ru.raiffeisen.courses.zoo.Cages.Cage;
import ru.raiffeisen.courses.zoo.Cages.Padok;
import ru.raiffeisen.courses.zoo.Cages.Voiler;
import ru.raiffeisen.courses.zoo.animals.Africa.Monkey;
import ru.raiffeisen.courses.zoo.animals.Animal;
import ru.raiffeisen.courses.zoo.animals.Europe.Eagle;

import java.util.Scanner;

public class Zoo {

    private Cage[] cages;


    public Zoo() {
        cages = new Cage[2];

        Animal[] animalsFirst = new Animal[2];
        animalsFirst[0] = new Monkey("Aby", "Brown", true, 4);
        animalsFirst[1] = new Monkey("BAby", "Black", false, 5);

        Cage first = new Voiler(animalsFirst, 10);
        cages[0] = first;

        Animal[] animalsSecond = new Animal[2];
        animalsSecond[0] = new Eagle("Aby", "Brown", (short) 10, 4);
        animalsSecond[1] = new Eagle("BAby", "grey", (short) 5, 5);
        Cage second = new Padok(animalsSecond, 10);
        cages[1] = second;
    }

    public boolean buyTicket() {
        boolean isTicketBougth = false;
        System.out.println("Do you want to buy ticket ?(Y/N");
        Scanner scanner = new Scanner(System.in);
        String clientAnswer = scanner.next();

        if (clientAnswer.toUpperCase().equals("Y")) {
            System.out.println("Congrat! You bougth ticket");
            isTicketBougth = true;
        } else {
            isTicketBougth = false;
        }
        return isTicketBougth;
    }


    public int getCageNumberByAnimalName(String animalName) {


        //return Animal[animalName].getCageNumber();

    }

    public String getCageReport(int cageNumber) {

        return cages[cageNumber].getCageDescription();

    }
}
