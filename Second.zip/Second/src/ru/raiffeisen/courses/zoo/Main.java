package ru.raiffeisen.courses.zoo;

public class Main {


    public static void main(String[] args) {
        Zoo zoo = new Zoo();


        if (zoo.buyTicket()) {
            System.out.println(zoo.getCageReport(0));

        }
        else{
            System.out.println("Access denied. You have to buy ticket");
        }

    }
}
