package ru.raiffeisen.courses.employes;

public class Boss extends Employee implements IDressCode, ISalaryTaker {

    private String ambitions;

    public String getAmbitions() {
        return ambitions;
    }

    public void setAmbitions(String ambitions) {
        this.ambitions = ambitions;
    }

    public Boss(String department) {
        super(department);//чтобы обращаться к классу родител\
    }

    @Override
    public String getDressCodedescription() {
        return "cool suit";
    }

    @Override
    public boolean accessToOfficeByDress(String dressName) {
        return false;
    }

    @Override
    public int getSalaryAmount() {
        return 150000;
    }

    @Override
    public void work() {
        System.out.println("ok");
    }

    @Override
    protected void smoke() {

    }
}
