package ru.raiffeisen.courses.employes;

public class Voluntuer extends Employee implements IDressCode{

      private boolean isStudent;

    public boolean isStudent() {
        return isStudent;
    }

    public void setStudent(boolean student) {
        isStudent = student;
    }

    public Voluntuer(String department) {
        super(department);
    }

    @Override
    public String getDressCodedescription() {
        return "something cheap";
    }

    @Override
    public boolean accessToOfficeByDress(String dressName) {
        return true;
    }

    @Override
    public void work() {
        System.out.println("take coffee to boss");
    }

    @Override
    protected void smoke() {

    }
}
