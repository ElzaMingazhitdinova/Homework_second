package ru.raiffeisen.courses.employes;

public class Worker extends  Employee implements ISalaryTaker {

    private  int strength;

    public int getStrength() {
        return strength;
    }

    public void setStrength(int strength) {
        this.strength = strength;
    }

    public Worker(String department) {
        super(department);
    }

    @Override
    public int getSalaryAmount() {
        return 50000;
    }

    @Override
    public void work() {
        System.out.println("work");
    }

    @Override
    protected void smoke() {

    }
}
