package ru.raiffeisen.courses.employes;

public abstract class Employee implements IHardWorker{

    private final String organizationName= "Raiffeisen";
    protected String department;

    public Employee(String department ) {
       this.department = organizationName + department;
    }



    protected abstract void smoke();
  }
