package ru.raiffeisen.courses.employes;

public interface ITaxPayer extends ISalaryTaker{

    float getTax(int salary);




}
