package ru.raiffeisen.courses.employes;

public interface IDressCode {
    String getDressCodedescription();
    boolean accessToOfficeByDress(String dressName);

}
