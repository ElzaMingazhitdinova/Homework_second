package ru.raiffeisen.courses.employes;

public interface IHardWorker {

    void work();

}
