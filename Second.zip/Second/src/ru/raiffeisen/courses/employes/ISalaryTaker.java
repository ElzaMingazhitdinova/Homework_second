package ru.raiffeisen.courses.employes;

public interface ISalaryTaker {

    int getSalaryAmount();
}
