package ru.raiffeisen.courses.employes;

public class Accounter extends Employee implements ITaxPayer {

    public Accounter(String department) {
        super(department);
    }


    @Override
    public float getTax(int salary) {
        return 1500;
    }

    @Override
    public int getSalaryAmount() {
        return 70000;
    }

    @Override
    public void work() {
        System.out.println("work");
    }

    @Override
    protected void smoke() {

    }
}
